import { sum, multiply } from '../src/index';

describe('Math functions', () => {
  test('sum adds two numbers', () => {
    expect(sum(2, 3)).toBe(5);
  });

  test('multiply multiplies two numbers', () => {
    expect(multiply(2, 3)).toBe(6);
  });
});