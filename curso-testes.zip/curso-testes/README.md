# Curso de Testes em TypeScript com Jest

Este projeto contém exemplos e exercícios para aprender a escrever testes unitários em TypeScript usando Jest.

## Instalação

```bash
npm install
```

## Scripts

- `npm test`: Executa os testes
- `npm run build`: Compila o TypeScript
- `npm run test:watch`: Executa os testes em modo watch

## Estrutura do Projeto

- `src/`: Código fonte
- `__tests__/`: Testes
- `mocks/`: Mocks para testes

## Como Contribuir

1. Faça um fork do projeto
2. Crie uma branch para sua feature (`git checkout -b feature/nova-feature`)
3. Commit suas mudanças (`git commit -am 'Adiciona nova feature'`)
4. Push para a branch (`git push origin feature/nova-feature`)
5. Abra um Pull Request